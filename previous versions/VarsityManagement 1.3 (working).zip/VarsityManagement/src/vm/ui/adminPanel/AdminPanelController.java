/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vm.ui.adminPanel;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import database.DatabaseHandler;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;

/**
 * FXML Controller class
 *
 * @author dipta10
 */
public class AdminPanelController implements Initializable {

    @FXML
    private JFXTextField studentId;
    @FXML
    private JFXButton addStudent;
    
    DatabaseHandler handler = DatabaseHandler.getInstance();
    @FXML
    private JFXTextField teacherId;
    @FXML
    private JFXTextField teacherName;
    @FXML
    private JFXTextField teacherEmail;
    @FXML
    private JFXTextField teacherPhone;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void addStudent(ActionEvent event) {
        if (studentId.getText().isEmpty()) {
            showAlert("Enter student ID first", Alert.AlertType.ERROR);
            return;
        }
        String query = "INSERT INTO student_info values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement statement = handler.con.prepareStatement(query);
            statement.setString(1, studentId.getText());
            statement.setString(2, "123456");
            statement.setString(3, null);
            statement.setInt(4, 0);
            statement.setInt(5, 0);
            statement.setString(6, null);
            statement.setBinaryStream(7, null);
            statement.setString(8 , null);
            statement.setString(9 , null);
            statement.setString(10 , null);
            statement.setString(11 , null);
            statement.setString(12 , null);
            statement.setString(13 , null);
            statement.setString(14 , null);
            statement.setBoolean(15, true);
            statement.setBoolean(16, true);
            statement.setInt(17, 0);
            statement.execute();
            
            showAlert("Student added!", Alert.AlertType.INFORMATION);
        } catch (SQLException ex) {
            Logger.getLogger(AdminPanelController.class.getName()).log(Level.SEVERE, null, ex);
            showAlert("Failed to add Student", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void addTeacher(ActionEvent event) {
        if (teacherId.getText().isEmpty() || teacherName.getText().isEmpty() || teacherEmail.getText().isEmpty() || teacherPhone.getText().isEmpty()) {
            showAlert("please first fill in all the fields to add teacher", Alert.AlertType.ERROR);
            return;
        }
        if (!isNumber(teacherPhone.getText())) {
            showAlert("Teacher's phone should be a number", Alert.AlertType.ERROR);
            return;
        }
        
        String query = "INSERT INTO teachers_info values(?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement statement = handler.con.prepareStatement(query);
            
            statement.setString(1, teacherId.getText());
            statement.setString(2, "123456");
            statement.setString(3, teacherName.getText());
            statement.setString(4, teacherPhone.getText());
            statement.setString(5, teacherEmail.getText());
            statement.setString(6, null);
            statement.setBoolean(7, true);
            statement.setBinaryStream(8, null);
            
            statement.execute();
            
            showAlert("Teacher added!", Alert.AlertType.INFORMATION);
        } catch (SQLException ex) {
            Logger.getLogger(AdminPanelController.class.getName()).log(Level.SEVERE, null, ex);
            showAlert("Failed to add Teacher", Alert.AlertType.ERROR);
        }
        
    }
    
    boolean isNumber(String input) {
        try {
            long l = Long.parseLong(input);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    void showAlert (String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
}
