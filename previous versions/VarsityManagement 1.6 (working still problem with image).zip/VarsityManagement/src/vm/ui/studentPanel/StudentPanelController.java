/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vm.ui.studentPanel;

import database.DatabaseHandler;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import sampleClass.MyDetails;

/**
 * FXML Controller class
 *
 * @author dipta10
 */
public class StudentPanelController implements Initializable {

    DatabaseHandler handler = DatabaseHandler.getInstance();
    private FileInputStream fis;
    @FXML
    private Label myId;
    @FXML
    private Label myName;
    @FXML
    private Label mySem;
    @FXML
    private Label myYear;
    @FXML
    private Label mySection;
    @FXML
    private Label myMobile;
    @FXML
    private Label myEmail;
    @FXML
    private Label myFatherName;
    @FXML
    private Label myMotherName;
    @FXML
    private Label myFatherMobile;
    @FXML
    private Label myMotherMobile;
    @FXML
    private Label myBloodGroup;
    @FXML
    private Label noImageAvailable;
    @FXML
    private Button chooseImage;
    @FXML
    private ImageView imageView;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        setupPersonalInfoTab();
    }    

    void setUpImage() {
        if (MyDetails.Student.fis != null) {
            imageView.setImage(new Image(fis));
//            noImageAvailable.setVisible(false);
//            chooseImage.setVisible(false);
        } else {
            System.out.println("Image not found in fis");
            if (MyDetails.Student.imagePath != null) {
                System.out.println("Image found in blob");
                try {
                    imageView.setImage(new Image(MyDetails.Student.imagePath.getBinaryStream()));
//                    noImageAvailable.setVisible(false);
//                    chooseImage.setVisible(false);
                } catch (SQLException ex) {
                    Logger.getLogger(StudentPanelController.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                System.out.println("Image not found in blob");
            }
        }
    }
    
    private void setupPersonalInfoTab() {
        myId.setText(MyDetails.myId);
        myName.setText(MyDetails.Student.name);
        System.out.println("My Name: " + MyDetails.Student.name);
        mySem.setText(MyDetails.Student.semester);
        myYear.setText(MyDetails.Student.year);
        mySection.setText(MyDetails.Student.section);
        myMobile.setText(MyDetails.Student.mobile);
        myEmail.setText(MyDetails.Student.email);
        myFatherName.setText(MyDetails.Student.fatherName);
        myFatherMobile.setText(MyDetails.Student.fatherMobile);
        myMotherMobile.setText(MyDetails.Student.motherMobile);
        myMotherName.setText(MyDetails.Student.motherName);
        myBloodGroup.setText(MyDetails.Student.bloodGroup);
        setUpImage();
    }

    @FXML
    private void chooseImage(ActionEvent event) {
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Images", "*.jpg"));
        File selectedFile = fc.showOpenDialog(null);
        try {
            if (selectedFile != null) {
                fis = new FileInputStream(selectedFile);
                noImageAvailable.setVisible(false);
//                chooseImage.setVisible(false);
                imageView.setImage(new Image(fis));
                
                if (fis != null) {
            // this means that I can upload an image
            
            String query = "UPDATE student_info SET image=? WHERE id = '"  + MyDetails.myId + "'";
            try {
                System.out.println("fis: " + fis.toString());
                System.out.println("query: " + query);
                PreparedStatement ps = handler.con.prepareStatement(query);
                ps.setBinaryStream(1, fis);
                ps.execute();
                ps.close();
                System.out.println("I am uploading image");

            } catch (SQLException ex) {
                Logger.getLogger(StudentPanelController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

            }
        } catch (IOException ex) {
            Logger.getLogger(StudentPanelController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
}
