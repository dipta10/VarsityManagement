
package sampleClass;

import java.io.FileInputStream;
import java.sql.Blob;
import javafx.scene.control.Alert;

public class MyDetails {
    public static String myId;
    public static String myPassword;
    
    public void showAlert(String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
    }
    
    public static class Student {
        public static String name;
        public static String mobile;
        public static String email;
        public static String fatherName;
        public static String motherName;
        public static String fatherMobile;
        public static String motherMobile;
        public static String section;
        public static String bloodGroup;
        public static String semester;
        public static String year;
        public static FileInputStream fis;
        public static Blob imagePath;
    }
       
    
    public static class Teacher {
        public static String name;
        public static String id;
        public static String mobile;
        public static String email;
        public static String description;
    }
    
}
